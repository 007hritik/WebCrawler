create function round(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.round($1,0)
$$;

comment on function round(numeric) is 'value rounded to ''scale'' of zero';

alter function round(numeric) owner to postgres;

